package com.example.jasmeetsingh.readapp;

/**
 * Created by Aniket Agarwal on 16-03-2018.
 */

public class books {
    // fields
    private int bookid;
    private String bookname;
    private String author;
    private String publisher;
    private String owner;
    private String type;//Paper back or Hard Bound
    // constructors
    public books() {}
    public books(int id, String name, String author, String publisher, String owner, String type ) {
        this.bookid = id;
        this.bookname = bookname;
        this.author = author;
        this.publisher = publisher;
        this.owner = owner;
        this.type = type;
    }
    // properties
    public void setID(int id) {
        this.bookid = id;
    }
    public int getID() {
        return this.bookid;
    }
    public void setbookName(String name) {
        this.bookname = name;
    }
    public String getbookName() {
        return this.bookname;
    }
    public void setauthor(String name) {
        this.author = name;
    }
    public String getauthor() {
        return this.author;
    }
    public void  setpublisher(String name) {
        this.publisher = name;
    }
    public String getpublisher() {
        return this.publisher;
    }
    public void setowner(String name) {
        this.owner = name;
    }
    public String getowner() {
        return this.owner;
    }
    public void settype(String name) {
        this.type = name;
    }
    public String gettype() {
        return this.type;
    }
}