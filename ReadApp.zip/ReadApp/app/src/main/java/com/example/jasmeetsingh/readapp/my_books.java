package com.example.jasmeetsingh.readapp;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class my_books extends AppCompatActivity {
    TextView lst;
    EditText bookid;
    EditText bookname,author,publisher, owner,type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Context context = getApplicationContext();
        CharSequence text = "Hello toast!";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_books);

        Button showFactButton = (Button) findViewById(R.id.button9);
        showFactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = getApplicationContext();
                CharSequence text = "Hello toast!";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();


//Your Code
            }});

    }

    public void load_books(View view) {
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
        //lst.setText(dbHandler.book_load_handler());
        bookid.setText("");
        bookname.setText("");
        author.setText("");
        publisher.setText("");
        owner.setText("");
        type.setText("");
    }
    public void add_books(View view) {
        Context context = getApplicationContext();
        CharSequence text = "Hello toast!";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
        int id = Integer.parseInt(bookid.getText().toString());
        String name = bookname.getText().toString();
        String author1 = author.getText().toString();
        String publisher1 = publisher.getText().toString();
        String owner1 = owner.getText().toString();
        String type1 = type.getText().toString();
        books book = new books(id, name, author1, publisher1, owner1, type1);
        dbHandler.book_add_handler(book);
        bookid.setText("");
        bookname.setText("");
        author.setText("");
        publisher.setText("");
        owner.setText("");
        type.setText("");
    }
    public void find_books(View view) {
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
        books book =  dbHandler.book_find_handler(bookname.getText().toString());
        if (book != null) {
            lst.setText(String.valueOf(book.getID()) + " " + book.getbookName() + " " + book.getauthor() + " " +
                    book.getpublisher() + " " + book.getowner() + " " + book.gettype() +
                    System.getProperty("line.separator"));
            bookid.setText("");
            bookname.setText("");
            author.setText("");
            publisher.setText("");
            owner.setText("");
            type.setText("");
        }
        else {
            lst.setText("No Match Found");
            bookid.setText("");
            bookname.setText("");
            author.setText("");
            publisher.setText("");
            owner.setText("");
            type.setText("");
        }
    }
    public void remove_books(View view) {
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
        boolean result = dbHandler.book_delete_handler(Integer.parseInt(bookid.getText().toString()));
        if (result) {
            bookid.setText("");
            bookname.setText("");
            author.setText("");
            publisher.setText("");
            owner.setText("");
            type.setText("");
            lst.setText("Record Deleted");
        }
        else
            bookid.setText("No Match Found");
    }
    /*
    public void update_books(View view) {
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
        boolean result = dbHandler.book_update_handler(Integer.parseInt(bookid.getText().toString()), bookname.getText().toString(), author.getText().toString(),
                publisher.getText().toString(), owner.getText().toString(), type.getText().toString());
        if (result) {
            bookid.setText("");
            bookname.setText("");
            author.setText("");
            publisher.setText("");
            owner.setText("");
            type.setText("");
            lst.setText("Record Updated");
        }
        else
            bookid.setText("No Match Found");
    }
    */
}

/*
public void load_borrower(View view) {
 MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
 lst.setText(dbHandler.borrower_load_handler());
 borrow_id.setText("");
 lenders_id.setText("");
 book_id.setText("");
 date_of_return.setText("");
 date_of_borrow.setText("");
}
public void find_borrower(View view) {
 MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
 borrower borrow =  dbHandler.borrower_find_handler(book.getText().toString());
 if (borrow != null) {
 lst.setText(String.valueOf(borrow.get_book_id()) + " "  +borrow.get_borrower_id()) + " "  +borrow.get_lenders_id()) + " "  +
                          borrow.get_doreturn()) + " "  +borrow.get_doborrow()) + " "  +System.getProperty("line.separator"));
 borrow_id.setText("");
 lenders_id.setText("");
 book_id.setText("");
 date_of_return.setText("");
 date_of_borrow.setText("");
 }
  else {
 lst.setText("No Match Found");
 borrow_id.setText("");
 lenders_id.setText("");
 book_id.setText("");
 date_of_return.setText("");
 date_of_borrow.setText("");
 }
}
 */
